//! Complete-input identity across fragmented and failed reads.

use std::io::{self, Read};

use sail_key::{sha256, sha256_reader};

struct Fragmented<'a> {
    remaining: &'a [u8],
    interrupt: bool,
    fragment: usize,
}

impl Read for Fragmented<'_> {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        self.interrupt = !self.interrupt;
        if self.interrupt {
            return Err(io::ErrorKind::Interrupted.into());
        }
        let bytes = self.remaining.len().min(buffer.len()).min(self.fragment);
        buffer[..bytes].copy_from_slice(&self.remaining[..bytes]);
        self.remaining = &self.remaining[bytes..];
        Ok(bytes)
    }
}

#[test]
fn fragmented_interrupted_reads_hash_every_byte_through_eof() -> io::Result<()> {
    let bytes: Vec<u8> = (0..=255).cycle().take(256 * 1024 + 17).collect();
    for fragment in [1, 63, 64, 65, 65_535, 65_536, 65_537] {
        let mut reader = Fragmented {
            remaining: &bytes,
            interrupt: false,
            fragment,
        };
        assert_eq!(sha256_reader(&mut reader)?, sha256(&bytes));
        assert!(reader.remaining.is_empty());
    }
    assert_eq!(sha256_reader(&mut &b""[..])?, sha256(b""));
    Ok(())
}

struct Failing {
    prefix_read: bool,
}

impl Read for Failing {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        if self.prefix_read {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "read refused",
            ));
        }
        self.prefix_read = true;
        buffer[..3].copy_from_slice(b"abc");
        Ok(3)
    }
}

#[test]
fn read_error_after_valid_prefix_never_returns_a_partial_identity() {
    let result = sha256_reader(&mut Failing { prefix_read: false });
    assert!(matches!(result, Err(error) if error.kind() == io::ErrorKind::PermissionDenied));
}

struct InvalidLength;

impl Read for InvalidLength {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        Ok(buffer.len() + 1)
    }
}

#[test]
fn invalid_reader_length_refuses_without_panicking() {
    let result = sha256_reader(&mut InvalidLength);
    assert!(matches!(result, Err(error) if error.kind() == io::ErrorKind::InvalidData));
}
