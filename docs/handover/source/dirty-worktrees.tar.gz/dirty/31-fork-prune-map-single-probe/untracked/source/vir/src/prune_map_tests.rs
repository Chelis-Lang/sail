//! Differential controls for the actual four prune map-builder call sites.
use super::{ReachedType, push_borrowed, push_owned};
use crate::ast::{CrateId, Dt, FunX, Path, PathX};
use std::cell::Cell;
use std::collections::{HashMap, hash_map::RandomState};
use std::fmt::Debug;
use std::hash::{Hash, Hasher};
use std::rc::Rc;
use std::sync::Arc;

#[derive(Default)]
struct Counts {
    hashes: Cell<usize>,
    clones: Cell<usize>,
}

struct Key<K, const COLLIDE: bool> {
    value: K,
    counts: Rc<Counts>,
}

impl<K: Clone, const COLLIDE: bool> Clone for Key<K, COLLIDE> {
    fn clone(&self) -> Self {
        self.counts.clones.set(self.counts.clones.get() + 1);
        Self { value: self.value.clone(), counts: self.counts.clone() }
    }
}

impl<K: PartialEq, const COLLIDE: bool> PartialEq for Key<K, COLLIDE> {
    fn eq(&self, other: &Self) -> bool {
        self.value == other.value
    }
}
impl<K: Eq, const COLLIDE: bool> Eq for Key<K, COLLIDE> {}

impl<K: Hash, const COLLIDE: bool> Hash for Key<K, COLLIDE> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.counts.hashes.set(self.counts.hashes.get() + 1);
        if COLLIDE {
            // Deliberately collapse every hash while retaining full key equality.
            0usize.hash(state);
        } else {
            self.value.hash(state);
        }
    }
}

// Keep the accepted implementation as the complete old map/vector oracle.
fn old_push<K: Hash + Eq + Clone, V>(map: &mut HashMap<K, Vec<V>>, key: &K, value: V) {
    if !map.contains_key(key) {
        map.insert(key.clone(), Vec::new());
    }
    map.get_mut(key).unwrap().push(value);
}

fn check<K: Clone + Eq + Hash + Debug, const COLLIDE: bool>(events: &[(K, u32)], reserve: usize) {
    let seed = RandomState::new();
    let old_counts = Rc::new(Counts::default());
    let owned_counts = Rc::new(Counts::default());
    let borrowed_counts = Rc::new(Counts::default());
    let mut old = HashMap::with_capacity_and_hasher(reserve, seed.clone());
    let mut owned = HashMap::with_capacity_and_hasher(reserve, seed.clone());
    let mut borrowed = HashMap::with_capacity_and_hasher(reserve, seed);
    let mut unique = Vec::new();
    for (value, item) in events {
        if !unique.contains(value) {
            unique.push(value.clone());
        }
        old_push(
            &mut old,
            &Key::<_, COLLIDE> { value: value.clone(), counts: old_counts.clone() },
            *item,
        );
        push_owned(
            &mut owned,
            Key::<_, COLLIDE> { value: value.clone(), counts: owned_counts.clone() },
            *item,
        );
        push_borrowed(
            &mut borrowed,
            &Key::<_, COLLIDE> { value: value.clone(), counts: borrowed_counts.clone() },
            *item,
        );
    }
    // Capture counts before any inspection of the tables can hash a query.
    let hashes = (old_counts.hashes.get(), owned_counts.hashes.get(), borrowed_counts.hashes.get());
    assert_eq!(old_counts.clones.get(), unique.len());
    assert_eq!(owned_counts.clones.get(), 0);
    assert_eq!(borrowed_counts.clones.get(), unique.len());
    let view = |map: &HashMap<Key<K, COLLIDE>, Vec<u32>>| {
        map.iter().map(|(k, v)| (k.value.clone(), v.clone(), v.capacity())).collect::<Vec<_>>()
    };
    // Same seed and insertion sequence: preserve bucket iteration too, not just
    // a sorted map comparison. Include all duplicate vector entries and capacity.
    assert_eq!(view(&old), view(&owned));
    assert_eq!(view(&old), view(&borrowed));
    assert_eq!(old.capacity(), owned.capacity());
    assert_eq!(old.capacity(), borrowed.capacity());
    for key in &unique {
        let expected = events.iter().filter(|(k, _)| k == key).map(|(_, v)| *v).collect::<Vec<_>>();
        let actual = owned.iter().find(|(k, _)| &k.value == key).unwrap().1;
        assert_eq!(actual, &expected);
    }
    if events.is_empty() {
        assert_eq!(hashes, (0, 0, 0));
    } else if reserve >= unique.len() {
        // A reserved table isolates query hashing from growth rehashes. The
        // first contains/get_mut sees an empty table and skips hashing.
        assert_eq!(hashes.0, 2 * events.len() + unique.len() - 1);
        assert_eq!(hashes.1, events.len());
        assert_eq!(hashes.2, events.len() + unique.len() - 1);
    } else {
        assert!(hashes.1 < hashes.0);
        assert!(hashes.2 < hashes.0);
    }
}

fn path(krate: CrateId, segments: &[&str]) -> Path {
    Arc::new(PathX {
        krate,
        segments: Arc::new(segments.iter().map(|s| Arc::new((*s).to_owned())).collect()),
    })
}

#[test]
fn owned_builder_preserves_paths_duplicates_and_declaration_order() {
    let first = path(CrateId::Id(Arc::new("same".to_owned()), 17), &["module", "item"]);
    let equal = path(CrateId::Id(Arc::new("same".to_owned()), 17), &["module", "item"]);
    assert_eq!(first, equal);
    assert!(!Arc::ptr_eq(&first, &equal));
    let other_crate = path(CrateId::Id(Arc::new("same".to_owned()), 18), &["module", "item"]);
    let other_segment = path(CrateId::Id(Arc::new("same".to_owned()), 17), &["module", "item2"]);
    let events = vec![
        (first.clone(), 7),
        (other_crate.clone(), 11),
        (equal.clone(), 7),
        (other_segment.clone(), 19),
        (first.clone(), 23),
        (other_crate.clone(), 11),
        (path(CrateId::Internal, &[]), 29),
        (path(CrateId::Vstd, &["module", "item"]), 31),
        (equal, 37),
    ];
    for reserve in [0, 32] {
        check::<_, false>(&events, reserve);
        check::<_, true>(&events, reserve);
    }
}

#[test]
fn borrowed_builder_preserves_nested_types_without_duplicate_clones() {
    let datatype = path(CrateId::Vstd, &["seq", "Seq"]);
    let fun = Arc::new(FunX { path: path(CrateId::Vstd, &["seq", "Seq", "new"]) });
    let nested = ReachedType::FnDef(
        fun.clone(),
        vec![
            ReachedType::Datatype(Dt::Path(datatype.clone())),
            ReachedType::FnDef(fun, vec![ReachedType::Bool]),
        ],
    );
    let events = vec![
        (nested.clone(), 41),
        (ReachedType::None, 43),
        (ReachedType::Datatype(Dt::Path(datatype)), 47),
        (nested.clone(), 41),
        (ReachedType::Datatype(Dt::Tuple(2)), 53),
        (nested.clone(), 59),
        (ReachedType::None, 43),
        (nested, 61),
    ];
    for reserve in [0, 32] {
        check::<_, false>(&events, reserve);
        check::<_, true>(&events, reserve);
    }
}

#[test]
fn builders_match_all_short_event_streams_and_growth() {
    let keys = [
        path(CrateId::Core, &["same"]),
        path(CrateId::Alloc, &["same"]),
        path(CrateId::Vstd, &["same"]),
    ];
    let mut growth = Vec::new();
    for index in 0..128u32 {
        let name = index.to_string();
        let key = path(CrateId::Core, &["growth", &name]);
        growth.push((key.clone(), index));
        growth.push((key, index % 7));
    }
    for reserve in [0, 256] {
        check::<_, false>(&growth, reserve);
        check::<_, true>(&growth, reserve);
    }
    let mut cases = 0;
    for len in 0..=5u32 {
        for mut code in 0..3usize.pow(len) {
            let mut events = Vec::new();
            for index in 0..len {
                events.push((keys[code % 3].clone(), index % 2));
                code /= 3;
            }
            for reserve in [0, 8] {
                check::<_, false>(&events, reserve);
                check::<_, true>(&events, reserve);
                cases += 2;
            }
        }
    }
    assert_eq!(cases, 1456); // 364 streams ×2 collision modes ×2 capacities.
}
