# Prospective R8 setup accounting review

Reviewed 2026-10-19 during handover. Source-only approved: the sole operator setup assertion increases180→300 seconds; worker setup600 and all product/oracle command caps stay unchanged. Total9570<=9600, remaining-worker assertion9270 stays intact, leaving30 seconds at worst-case setup. This changes an operational preworker transfer allowance, not a test baseline. No live deadline is extended. Fresh successor packet/auth/disk/capacity admission is required. No host launched by this review. Late-guard helper correctness/execution is a separate pending gate.

Diff SHA-256: `4ba3b151872ed44d1e14200b0dfd661887dc6604f185563c30e820c9cf3c4b7b`.
