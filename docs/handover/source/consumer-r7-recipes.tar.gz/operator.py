"""Official host, exact SCP, one gate, unconditional exact-lane teardown."""
import datetime,hashlib,json,os,pathlib,re,shlex,signal,stat,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent;plan=json.loads((root/'plan.json').read_text());admit=json.loads((root/'admission.json').read_text());lane=plan['lane'];script='/Users/jeff/code/sail/scripts/perf-host.sh';env=dict(os.environ,AWS_CONFIG_FILE=admit['aws_config_file'],AWS_PROFILE='AdminAccess-010928226848',AWS_REGION='us-east-1',SAIL_PERF_TTL_MIN=str(plan['frame_minutes']['ttl']));state=pathlib.Path('/Users/jeff/.sail-perf')/(lane+'.env');remote='/home/ubuntu/sail-cbb-first-use-r7';status={'passed':False,'errors':[]};process=None;up_process=None;up_started=False

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():
 temporary=root/'operator-status.tmp';temporary.write_text(json.dumps(status,indent=2)+'\n');os.replace(temporary,root/'operator-status.json')
def stop(_sig,_frame):raise KeyboardInterrupt('operator interrupted')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,stop)
def run(argv,cap,label,capture=False):
 global process
 with (root/(label+'.log')).open('wb') as log:
  process=subprocess.Popen(argv,env=env,stdout=subprocess.PIPE if capture else log,stderr=log,start_new_session=True)
  try:body,_=process.communicate(timeout=cap)
  except BaseException:
   try:os.killpg(process.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:process.wait(timeout=30)
   except subprocess.TimeoutExpired:
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    process.wait(timeout=10)
   raise
  rc=process.returncode;process=None;assert rc==0,label+' exit '+str(rc)
 return body

def aws(args):return json.loads(run(['aws']+args+['--region','us-east-1','--output','json'],30,'aws-'+str(time.time_ns()),True))
def ssh(command,cap,label):return run(['ssh']+opts+['ubuntu@'+host['addr'],command],cap,label,True)
def retire():
 """Reconcile only this freshly empty, then owned lane, including partial up."""
 deadline=time.monotonic()+240;proof={'instances':{},'volume_ids':[],'eni_ids':[],'attempts':[],'passed':False};volumes=set();enis=set()
 def call(args,mutation=False):
  remaining=deadline-time.monotonic();assert remaining>0,'retirement budget exhausted'
  result=subprocess.run(['aws']+args+['--region','us-east-1','--output','json'],env=env,capture_output=True,timeout=min(10,remaining))
  proof['attempts'].append({'args':args,'exit':result.returncode,'stdout':result.stdout.decode(errors='replace'),'stderr':result.stderr.decode(errors='replace')})
  (root/'retirement.json').write_text(json.dumps(proof,indent=2)+'\n')
  if result.returncode:
   if mutation:return None
   raise RuntimeError('retirement read refused')
  return json.loads(result.stdout or b'{}')
 def owned(row):
  tags=dict((x['Key'],x['Value']) for x in row.get('Tags',[]));return tags.get('Project')=='sail' and tags.get('Lane')==lane
 def query():
  instances=[i for reservation in call(['ec2','describe-instances','--filters','Name=tag:Project,Values=sail','Name=tag:Lane,Values='+lane])['Reservations'] for i in reservation['Instances']]
  groups=call(['ec2','describe-security-groups','--filters','Name=tag:Project,Values=sail','Name=tag:Lane,Values='+lane])['SecurityGroups']
  keys=call(['ec2','describe-key-pairs','--filters','Name=key-name,Values=sail-'+lane])['KeyPairs']
  return instances,groups,keys
 try:
  initial_instances,initial_groups,initial_keys=query();proof['initial']={'instances':initial_instances,'groups':initial_groups,'keys':initial_keys}
  saved=[status['actual_identity']] if 'actual_identity' in status else []
  for item in initial_instances+saved:
   assert owned(item) and item['InstanceType']=='c7i.4xlarge';proof['instances'][item['InstanceId']]=item
   for mapping in item.get('BlockDeviceMappings',[]):
    if 'Ebs' in mapping:assert mapping['Ebs']['DeleteOnTermination'];volumes.add(mapping['Ebs']['VolumeId'])
   enis.update(x['NetworkInterfaceId'] for x in item.get('NetworkInterfaces',[]))
  if state.is_file():
   try:run(['bash',script,'down',lane],min(120,deadline-time.monotonic()),'exact-down');proof['official_down_passed']=True
   except BaseException as error:proof['official_down_error']=repr(error)
  while time.monotonic()<deadline:
   instances,groups,keys=query();live=[]
   for item in instances:
    assert owned(item) and item['InstanceType']=='c7i.4xlarge'
    proof['instances'][item['InstanceId']]=item
    for mapping in item.get('BlockDeviceMappings',[]):
     if 'Ebs' in mapping:assert mapping['Ebs']['DeleteOnTermination'];volumes.add(mapping['Ebs']['VolumeId'])
    enis.update(x['NetworkInterfaceId'] for x in item.get('NetworkInterfaces',[]))
    if item['State']['Name']!='terminated':live.append(item['InstanceId'])
   if live:call(['ec2','terminate-instances','--instance-ids']+live,True)
   current_enis=call(['ec2','describe-network-interfaces','--filters','Name=network-interface-id,Values='+','.join(sorted(enis))])['NetworkInterfaces'] if enis else []
   current_volumes=call(['ec2','describe-volumes','--filters','Name=volume-id,Values='+','.join(sorted(volumes))])['Volumes'] if volumes else []
   for item in current_enis:
    if item['Status']=='available':call(['ec2','delete-network-interface','--network-interface-id',item['NetworkInterfaceId']],True)
   for item in current_volumes:
    if item['State']=='available' and not item['Attachments']:call(['ec2','delete-volume','--volume-id',item['VolumeId']],True)
   for item in groups:
    assert owned(item) and item['GroupName']=='sail-'+lane;call(['ec2','delete-security-group','--group-id',item['GroupId']],True)
   for item in keys:
    assert owned(item) and item['KeyName']=='sail-'+lane;call(['ec2','delete-key-pair','--key-name',item['KeyName']],True)
   proof.update(volume_ids=sorted(volumes),eni_ids=sorted(enis),final={'instances':instances,'groups':groups,'keys':keys,'volumes':current_volumes,'enis':current_enis})
   if not live and not groups and not keys and not current_enis and not current_volumes:
    for suffix in ['.env','.pem','.known_hosts']:
     p=state.with_suffix(suffix)
     if p.exists():assert stat.S_ISREG(p.lstat().st_mode);p.unlink()
    proof['passed']=True;break
   time.sleep(2)
  assert proof['passed'],'owned resources not proven absent'
 finally:(root/'retirement.json').write_text(json.dumps(proof,indent=2)+'\n')
 return proof

# One bounded recovery budget for this owned host, including final capture.
recovery_left=100.0
def recover_route(maximum):
 global recovery_left
 started=time.monotonic();deadline=started+min(recovery_left,maximum)
 def bounded(argv,cap,label,capture=True):
  left=deadline-time.monotonic();assert left>0,'transport recovery budget exhausted'
  return run(argv,min(cap,left),label+'-'+str(time.time_ns()),capture)
 def api(args):return json.loads(bounded(['aws']+args+['--region','us-east-1','--output','json'],10,'route-api'))
 try:
  group=api(['ec2','describe-security-groups','--group-ids',host['sg']])['SecurityGroups'][0]
  assert dict((x['Key'],x['Value']) for x in group['Tags'])=={'Project':'sail','Lane':lane}
  candidates={'87.119.84.106','213.235.5.19'}
  try:
   ip=bounded(['curl','--noproxy','*','-4','--connect-timeout','5','--max-time','8','https://checkip.amazonaws.com'],8,'direct-egress').decode().strip()
   candidates.add(str(__import__('ipaddress').IPv4Address(ip)))
  except Exception as error:status.setdefault('route_observations',[]).append(repr(error))
  present={r['CidrIp'] for p in group['IpPermissions'] for r in p.get('IpRanges',[])}
  for ip in sorted(candidates):
   if ip+'/32' not in present:api(['ec2','authorize-security-group-ingress','--group-id',host['sg'],'--protocol','tcp','--port','22','--cidr',ip+'/32'])
  peer=bounded(['ssh']+opts+['ubuntu@'+host['addr'],'printf "%s\n" "$SSH_CONNECTION"'],10,'recovered-peer').decode().split()[0]
  assert peer in candidates
  group=api(['ec2','describe-security-groups','--group-ids',host['sg']])['SecurityGroups'][0]
  for permission in group['IpPermissions']:
   assert permission['IpProtocol']=='tcp' and permission['FromPort']==permission['ToPort']==22 and not permission.get('Ipv6Ranges') and not permission.get('UserIdGroupPairs')
   for row in permission.get('IpRanges',[]):
    if row['CidrIp']!=peer+'/32':api(['ec2','revoke-security-group-ingress','--group-id',host['sg'],'--protocol','tcp','--port','22','--cidr',row['CidrIp']])
  group=api(['ec2','describe-security-groups','--group-ids',host['sg']])['SecurityGroups'][0]
  assert len(group['IpPermissions'])==1 and group['IpPermissions'][0]['IpRanges']==[{'CidrIp':peer+'/32'}]
  status.setdefault('recovered_peers',[]).append(peer);save()
 finally:recovery_left=max(0,recovery_left-(time.monotonic()-started))
def transport(argv,cap,label,capture=False,first_cap=None):
 if label in ['complete-download','fallback-raw-download']:
  capture_deadline=time.monotonic()+cap
  import importlib.util,shutil
  guard_path=pathlib.Path('/Users/jeff/sail-raw-evidence/combined-8a-native-candidate-2026-10-16/collector_space_guard.py')
  assert sha(guard_path)=='c347c07b7086ef21c1800db3767840f1d66a062872dab1ae5f69916e633e7149'
  spec=importlib.util.spec_from_file_location('shared_native_space_guard',guard_path);guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
  attempts=0
  while time.monotonic()<capture_deadline:
   attempts+=1
   left=capture_deadline-time.monotonic()
   with guard.exclusive_fetch_slot(wait_seconds=min(2,max(0,left))) as acquired:
    if acquired:
     required=10*1024**3+plan['local_capture_reservation_bytes']+guard.MARGIN
     status['capture_disk_admission']={'actual_free_bytes':shutil.disk_usage(root).free,'minimum_free_bytes':required,'shared_lock':str(guard.LOCK_PATH),'slot_attempts':attempts,'slot_wait_seconds':cap-(capture_deadline-time.monotonic())};save()
     assert status['capture_disk_admission']['actual_free_bytes']>=required,'shared capture disk admission'
     left=capture_deadline-time.monotonic();assert left>0,'original transport cap exhausted waiting for shared slot'
     return transport(argv,left,label+'-space-admitted',capture,first_cap)
  raise TimeoutError('original transport cap exhausted waiting for shared slot')
 deadline=time.monotonic()+cap
 try:return run(argv,min(cap,first_cap) if first_cap is not None else cap,label,capture)
 except (AssertionError,subprocess.TimeoutExpired) as error:
  if isinstance(error,AssertionError) and not str(error).endswith(' exit 255'):raise
  status.setdefault('transport_incidents',[]).append({'label':label,'error':repr(error),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});save()
  left=deadline-time.monotonic();assert left>15,'original transport cap exhausted'
  recover_route(left-15);left=deadline-time.monotonic();assert left>0,'original transport cap exhausted'
  return run(argv,left,label+'-reconnected',capture)
def short_ssh(command,cap,label):
 deadline=time.monotonic()+cap
 while True:
  try:return transport(['ssh']+opts+['ubuntu@'+host['addr'],command],max(.001,deadline-time.monotonic()),label,True,20)
  except AssertionError as error:
   if not label.startswith('phase-status-') or not str(error).endswith(' exit 1'):raise
   left=deadline-time.monotonic()
   if left<=0:raise
   status.setdefault('status_poll_retries',[]).append({'label':label,'error':repr(error)});save()
   time.sleep(min(1,left))

try:
 assert time.time()+60<=admit['launch_cutoff_epoch'],'less than60 seconds remain before submission'
 expected=json.loads((root/'ops-files.json').read_text())
 for name,row in expected.items():
  p=root/name;assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],name
 binding=json.loads((root/'payload/producer-binding.json').read_text())
 assert binding['bound'] and binding['source']==plan['source'] and binding['producer_work_closed_verified'],'producer work must pass/strictcapture/close before UP'
 proof=pathlib.Path(binding['closed_producer_receipt_path']);assert sha(proof)==binding['closed_producer_receipt_sha256'] and json.loads(proof.read_text())['passed'],'actual closed producer strict capture receipt'
 for name,row in json.loads((root/'external-inputs.json').read_text()).items():
  path=pathlib.Path(row['path']);meta=path.lstat();assert stat.S_ISREG(meta.st_mode) and meta.st_size==row['bytes'] and stat.S_IMODE(meta.st_mode)==row['mode'] and sha(path)==row['sha256'],name
 proof=pathlib.Path(binding['producer_retirement_path']);assert sha(proof)==binding['producer_retirement_sha256'] and json.loads(proof.read_text())['passed'],'actual producer exact retirement'
 assert not state.exists(),'lane already has state'
 assert __import__('shutil').disk_usage(root).free>=admit['minimum_free_bytes'],'local disk admission'
 inventory=aws(['ec2','describe-instances','--filters','Name=instance-state-name,Values=pending,running'])
 vcpus=sum(i['CpuOptions']['CoreCount']*i['CpuOptions']['ThreadsPerCore'] for r in inventory['Reservations'] for i in r['Instances']);assert vcpus+16<=64,'self capacity'
 quota=aws(['service-quotas','get-service-quota','--service-code','ec2','--quota-code','L-1216C47A'])['Quota']['Value'];assert vcpus+16<=quota,'regional quota'
 initial_instances=aws(['ec2','describe-instances','--filters','Name=tag:Project,Values=sail','Name=tag:Lane,Values='+lane])['Reservations'];assert not any(r['Instances'] for r in initial_instances),'lane instance collision'
 assert not aws(['ec2','describe-security-groups','--filters','Name=tag:Project,Values=sail','Name=tag:Lane,Values='+lane])['SecurityGroups'],'lane group collision'
 assert not aws(['ec2','describe-key-pairs','--filters','Name=key-name,Values=sail-'+lane])['KeyPairs'],'lane key collision'
 # Follow the official up wait and admit only the already observed alternative /32.
 with (root/'up.log').open('wb') as log:
  assert time.time()+60<=admit['launch_cutoff_epoch'],'less than60 seconds remain before official up'
  up_started=True
  up_process=subprocess.Popen(['bash',script,'up',lane,'c7i.4xlarge'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);added=False
  while up_process.poll() is None:
   assert time.time()<admit['created_epoch']+300,'setup cap expired'
   if state.is_file() and not added:
    interim=dict(line.split('=',1) for line in state.read_text().splitlines() if '=' in line)
    if interim.get('sg'):
     group=aws(['ec2','describe-security-groups','--group-ids',interim['sg']])['SecurityGroups'][0]
     present={r['CidrIp'] for p in group['IpPermissions'] for r in p.get('IpRanges',[])}
     for cidr in ['87.119.84.106/32','213.235.5.19/32']:
      if cidr not in present:aws(['ec2','authorize-security-group-ingress','--group-id',interim['sg'],'--protocol','tcp','--port','22','--cidr',cidr])
     added=True
   time.sleep(2)
  assert up_process.returncode==0,'official up failed';up_process=None
 host=dict(line.split('=',1) for line in state.read_text().splitlines() if '=' in line);status['host']=host;save()
 opts=['-i',str(state.with_suffix('.pem')),'-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(state.with_suffix('.known_hosts')),'-o','ConnectTimeout=10','-o','ServerAliveInterval=30']
 peer=ssh('printf "%s\\n" "$SSH_CONNECTION"',15,'ssh-peer').decode().split()[0];assert peer in ['87.119.84.106','213.235.5.19'],peer
 group=aws(['ec2','describe-security-groups','--group-ids',host['sg']])['SecurityGroups'][0]
 for permission in group['IpPermissions']:
  assert permission['IpProtocol']=='tcp' and permission['FromPort']==permission['ToPort']==22 and not permission.get('Ipv6Ranges') and not permission.get('UserIdGroupPairs')
  for row in permission.get('IpRanges',[]):
   if row['CidrIp']!=peer+'/32':aws(['ec2','revoke-security-group-ingress','--group-id',host['sg'],'--protocol','tcp','--port','22','--cidr',row['CidrIp']])
 aws(['ec2','modify-instance-metadata-options','--instance-id',host['id'],'--http-tokens','required','--http-endpoint','enabled'])
 identity=aws(['ec2','describe-instances','--instance-ids',host['id']])['Reservations'][0]['Instances'][0];status['actual_identity']=identity;status['actual_ssh_peer']=peer
 assert identity['InstanceId']==host['id'] and identity['PublicIpAddress']==host['addr']
 assert identity['InstanceType']=='c7i.4xlarge' and identity['BlockDeviceMappings'][0]['Ebs']['DeleteOnTermination'] and identity['MetadataOptions']['HttpTokens']=='required'
 behavior=aws(['ec2','describe-instance-attribute','--instance-id',host['id'],'--attribute','instanceInitiatedShutdownBehavior']);assert behavior['InstanceInitiatedShutdownBehavior']['Value']=='terminate'
 assert dict((r['Key'],r['Value']) for r in identity['Tags'])['Lane']==lane
 group=aws(['ec2','describe-security-groups','--group-ids',host['sg']])['SecurityGroups'][0];permissions=group['IpPermissions'];assert len(permissions)==1 and permissions[0]['IpProtocol']=='tcp' and permissions[0]['FromPort']==permissions[0]['ToPort']==22 and permissions[0]['IpRanges']==[{'CidrIp':peer+'/32'}] and not permissions[0].get('Ipv6Ranges') and not permissions[0].get('UserIdGroupPairs')
 shutdown=ssh('sudo -n shutdown --show 2>&1',15,'watchdog').decode();status['watchdog']=shutdown
 stamps=re.findall(r'(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) UTC',shutdown);assert len(stamps)==1
 scheduled=datetime.datetime.strptime(stamps[0],'%Y-%m-%d %H:%M:%S').replace(tzinfo=datetime.timezone.utc).timestamp();launch=datetime.datetime.fromisoformat(identity['LaunchTime'].replace('Z','+00:00')).timestamp()
 assert launch<=admit['launch_cutoff_epoch'],'actual EC2 LaunchTime missed cutoff'
 assert (plan['frame_minutes']['ttl']-1)*60<=scheduled-launch<=(plan['frame_minutes']['ttl']+1)*60 and admit['outer_deadline_epoch']+300<scheduled<=admit['host_upper_epoch'];save()
 ssh('mkdir -m 0755 '+remote,15,'owned-root')
 run(['scp','-q']+opts+[str(root/'packet.tgz'),'ubuntu@'+host['addr']+':'+remote+'/packet.tgz'],120,'upload')
 assert ssh('sha256sum '+remote+'/packet.tgz',30,'remote-packet-sha').decode().split()[0]==sha(root/'packet.tgz')
 ssh('cd '+remote+' && tar -xzf packet.tgz && mkdir -m 0755 inputs',15,'extract-only')
 external=json.loads((root/'external-inputs.json').read_text())
 for name,row in external.items():
  path=pathlib.Path(row['path']);meta=path.lstat();assert stat.S_ISREG(meta.st_mode) and meta.st_size==row['bytes'] and stat.S_IMODE(meta.st_mode)==row['mode'] and sha(path)==row['sha256'],name
 run(['scp','-q']+opts+[row['path'] for row in external.values()]+['ubuntu@'+host['addr']+':'+remote+'/inputs/'],120,'upload-runtime-inputs')
 for name,row in external.items():
  original_name=pathlib.Path(row['path']).name
  if original_name!=name:ssh('mv -- '+shlex.quote(remote+'/inputs/'+original_name)+' '+shlex.quote(remote+'/inputs/'+name),10,'name-runtime-'+name)
  observed=ssh("stat -c '%a %s' "+shlex.quote(remote+'/inputs/'+name)+' && sha256sum '+shlex.quote(remote+'/inputs/'+name),20,'guard-runtime-'+name).decode().splitlines()
  assert observed[0].split()==[format(row['mode'],'o'),str(row['bytes'])] and observed[1].split()[0]==row['sha256'],name
 run(['scp','-p','-q']+opts+[str(root/'admission.json'),'ubuntu@'+host['addr']+':'+remote+'/admission.json'],15,'upload-admission')
 assert ssh('sha256sum '+remote+'/admission.json',10,'remote-admission-sha').decode().split()[0]==sha(root/'admission.json')
 # Actual physical identity is a separate operational input, never a source edit.
 (root/'consumer-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
 run(['scp','-p','-q']+opts+[str(root/'consumer-identity.json'),'ubuntu@'+host['addr']+':'+remote+'/consumer-identity.json'],15,'upload-consumer-identity')
 assert ssh('sha256sum '+remote+'/consumer-identity.json',10,'remote-consumer-identity-sha').decode().split()[0]==sha(root/'consumer-identity.json')
 assert time.time()<=admit['created_epoch']+180,'operator setup share180 expired; complete setup780 includes worker600'
 assert admit['work_deadline_epoch']-time.time()>=9270,'complete fixed worker queue unavailable'
 assert admit['instance_type']=='c7i.4xlarge'
 # The owned worker runs independently of a long-lived SSH connection.
 hard_stop=admit['outer_deadline_epoch']-840;seconds=int(hard_stop-time.time()-40);assert seconds>0
 body='python3 -B worker.py; result=$?; printf "%s\n" "$result" > worker-exit.tmp && mv -- worker-exit.tmp worker-exit; exit "$result"'
 launch='import os,pathlib,subprocess; r=pathlib.Path('+repr(remote)+'); log=(r/"worker.log").open("xb"); p=subprocess.Popen('+repr(['timeout','--signal=TERM','--kill-after=40s',str(seconds)+'s','bash','-c',body])+',cwd=r,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True); print(p.pid,flush=True)'
 command='python3 -I -c '+shlex.quote(launch)
 status['worker_launch_pid']=int(ssh(command,15,'detached-worker-launch').decode().strip());assert status['worker_launch_pid']>0;save()
 checkpoint=root/'phase-checkpoints';checkpoint.mkdir();last=None
 reader='import pathlib,json\nr=pathlib.Path(REMOTE_ROOT)\np=r/"evidence/status.json"\nf=p.open("rb") if p.exists() else None\nb=f.read(64*1024**2+1) if f else b"null"\nassert len(b)<=64*1024**2,"raw status exceeds64MiB"\nd=json.loads(b)\nif d is not None:\n d={"passed":d["passed"],"errors":d["errors"],"steps":[{k:step[k] for k in ("label","passed","seconds") if k in step} for step in d.get("steps",[])],"nine_rows":d.get("nine_rows"),"first_use_passed":d.get("first_use_passed"),"primary_interaction":None if d.get("primary_interaction") is None else {"passed":d["primary_interaction"]["passed"]},"vest_interaction":d.get("vest_interaction"),"source_runtime_products_final":d.get("source_runtime_products_final")}\ne=r/"worker-exit"\nbody=json.dumps({"status":d,"exit":int(e.read_text()) if e.exists() else None})\nassert len(body.encode())<=1048576,"compact control exceeds1MiB"\nprint(body)\n'.replace('REMOTE_ROOT',repr(remote))
 while time.time()<hard_stop:
  row=json.loads(short_ssh('python3 -c '+shlex.quote(reader),120,'phase-status-'+str(time.time_ns())))
  encoded=json.dumps(row,sort_keys=True)
  if encoded!=last:
   (checkpoint/(str(time.time_ns())+'.json')).write_text(encoded+'\n');last=encoded;status['last_remote_checkpoint']=row;save()
  if row['exit'] is not None:
   assert row['exit']==0,'actual worker exit '+str(row['exit'])
   assert row['status'] is not None and row['status']['passed'],'actual worker did not pass'
   break
  time.sleep(min(15,max(0,hard_stop-time.time())))
 else:raise TimeoutError('owned worker completion unavailable before original capture reserve')
 status['passed']=True
except BaseException as error:status['errors'].append(repr(error))
finally:
 if up_process is not None and up_process.poll() is None:
  try:os.killpg(up_process.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:up_process.wait(timeout=30)
  except subprocess.TimeoutExpired:
   os.killpg(up_process.pid,signal.SIGKILL);up_process.wait(timeout=10)
 # Copy final evidence even on a real command failure. Nothing is retried or reclassified.
 if 'host' in globals() and 'opts' in globals():
  try:transport(['scp','-q']+opts+['ubuntu@'+host['addr']+':'+remote+'/'+name for name in ['worker.log','result-receipt.json','result.tgz']]+[str(root)+'/'],180,'complete-download')
  except BaseException as error:status['errors'].append('complete capture '+repr(error));status['passed']=False
  try:
   receipt=json.loads((root/'result-receipt.json').read_text());archive=root/'result.tgz';assert archive.stat().st_size==receipt['bytes']<=512*1024**2 and sha(archive)==receipt['sha256'];assert receipt['raw_bytes']<=1024**3
   import tarfile
   with tarfile.open(archive,'r:gz') as t:
    index=None;actual={};total=0
    for m in t:
     path=pathlib.PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts
     if m.isdir():continue
     assert m.isfile();f=t.extractfile(m);assert f is not None;total+=m.size;assert total<=1024**3+16*1024**2
     if m.name=='capture-index.json':index=json.load(f)
     else:
      assert path.parts[0]=='evidence' and str(pathlib.PurePosixPath(*path.parts[1:])) not in actual;actual[str(pathlib.PurePosixPath(*path.parts[1:]))]={'bytes':m.size,'mode':m.mode,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
    assert index is not None and index['files']==actual and index['raw_bytes']==receipt['raw_bytes']
   status['strict_capture_passed']=True;status['passed']=status['passed'] and receipt['passed']
  except BaseException as error:status['errors'].append('strict archive '+repr(error));status['passed']=False
  if not status.get('strict_capture_passed'):
   try:
    code='import pathlib,hashlib,json,stat; r=pathlib.Path('+repr(remote)+'); p=[r/"worker.log",r/"evidence/status.json"]+list((r/"evidence").glob("*.log")); p=list(dict.fromkeys(q for q in p if q.exists())); assert len(p)<=32; assert all(stat.S_ISREG(q.lstat().st_mode) for q in p); assert sum(q.stat().st_size for q in p)<=1024**3; print(json.dumps({str(q.relative_to(r)):{"bytes":q.stat().st_size,"sha256":hashlib.file_digest(q.open("rb"),"sha256").hexdigest()} for q in p}))'
    raw=json.loads(short_ssh('python3 -c '+shlex.quote(code),120,'raw-log-inventory'));dest=root/'fallback-raw';dest.mkdir();(dest/'index.json').write_text(json.dumps(raw,indent=2)+'\n');assert raw
    for name in raw:assert re.fullmatch(r'(?:evidence/)?[a-zA-Z0-9.-]+',name)
    # SCP all available complete top-level command logs in one bounded transfer.
    transport(['scp','-q']+opts+['ubuntu@'+host['addr']+':'+remote+'/'+name for name in raw]+[str(dest)+'/'],180,'fallback-raw-download')
    for name,row in raw.items():
     q=dest/pathlib.Path(name).name;assert q.stat().st_size==row['bytes'] and sha(q)==row['sha256']
    status['fallback_complete_top_level_logs']=True;status['complete_evidence_archive']='unavailable; failure remains failure'
   except BaseException as error:status['errors'].append('raw fallback '+repr(error))
 if up_started:
  try:status['retirement']=retire()
  except BaseException as error:status['errors'].append('down '+repr(error));status['passed']=False
 status['passed']=status['passed'] and not status['errors'];save()
raise SystemExit(0 if status['passed'] else 1)
