#!/bin/bash
set -euo pipefail
cd ~/sail
. .m112/env.sh
cargo build -q --release -p sail-cli -p sail-shim -p sail-bench -p sail-conformance
native/sail-snap/build.sh
echo "PATH head: $(echo "$PATH" | tr : '\n' | head -3 | tr '\n' ' ')"
echo "fork dir: $SAIL_PERF_FORK_DIR"; ls "$SAIL_PERF_FORK_DIR" | tr '\n' ' '; echo
echo "stock z3: $STOCK_Z3"; file "$STOCK_Z3"
nm -D "$STOCK_Z3" | grep -E " U (getc|_IO_getc|fgetc|ungetc|fread|getchar)(@|$)" || true
ldd "$STOCK_Z3"
