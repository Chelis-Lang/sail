#!/bin/bash
# Host A: snapshot exactness over every captured transcript set.
set -uo pipefail
cd ~/sail
. .m112/env.sh
pkill -f a3-traces.sh; pkill -f snapshot-exactness; sleep 2
rm -rf /tmp/sx-*
E=~/m112
Z3="$SAIL_PERF_FORK_DIR/z3"
for p in ironkv anvil vest capybarakv verismo; do
  bash .m112/a2-exact.sh "$p" "$Z3" 8 $E/$p/trace/*/
done
bash .m112/a2-exact.sh fast "$Z3" 8 $E/conf-trace
echo A5-DONE
