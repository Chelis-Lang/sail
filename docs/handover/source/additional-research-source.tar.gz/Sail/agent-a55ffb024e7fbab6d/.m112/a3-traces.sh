#!/bin/bash
# Host A: transcripts for the L40 catalogue (fork Verus) and the fast tier,
# then snapshot exactness over all of them.
set -uo pipefail
cd ~/sail
. .m112/env.sh
cargo build -q --release -p sail-cli -p sail-shim -p sail-bench -p sail-conformance
native/sail-snap/build.sh
E=~/m112
Z3="$SAIL_PERF_FORK_DIR/z3"
echo "z3 sha256: $(sha256sum "$Z3" | cut -c1-64); stock: $(sha256sum "$STOCK_Z3" | cut -c1-64)"
./target/release/sail-conformance fetch --tier standard --project vest >/dev/null 2>&1
./target/release/sail-conformance fetch --tier standard --project verified-storage >/dev/null 2>&1
./target/release/sail-conformance fetch --tier standard --project verismo-main >/dev/null 2>&1
for p in anvil vest capybarakv verismo; do
  SAIL_PERF_FORK="$SAIL_PERF_FORK_DIR" SAIL_PERF_OUT=$E/$p scripts/perf-real.sh trace $p > $E/$p-trace.log 2>&1
  grep "trace " $E/$p-trace.log
done
./target/release/sail-conformance fetch --tier fast >/dev/null 2>&1
./target/release/sail-conformance run --tier fast --trace --jobs 8 --out $E/conf-trace > $E/conf-trace.log 2>&1
tail -3 $E/conf-trace.log
echo "fast transcripts: $(find $E/conf-trace -name '*.in.smt2' | wc -l)"
for p in ironkv anvil vest capybarakv verismo; do
  bash .m112/a2-exact.sh "$p" "$Z3" 8 $E/$p/trace/*/
done
bash .m112/a2-exact.sh fast "$Z3" 8 $E/conf-trace
echo A3-DONE
