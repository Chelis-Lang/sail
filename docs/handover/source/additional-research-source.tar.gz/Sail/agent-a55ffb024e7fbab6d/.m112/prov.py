"""prov.py OUT ROUND: per phase, sessions that started a solver, and where snapshot ones resumed."""
import glob, json, os, sys
out, rnd = sys.argv[1], sys.argv[2]
for d in sorted(glob.glob(f"{out}/r{rnd}/prov/*")):
    rows = []
    for f in glob.glob(d + "/*.json"):
        try:
            rows.append(json.load(open(f)))
        except Exception:
            pass
    started = [r for r in rows if r.get("solver_started")]
    print(os.path.basename(d), "started", len(started),
          "served/resumed_at:", [(r["replies_served"], r.get("snapshot_resumed_at")) for r in started])
