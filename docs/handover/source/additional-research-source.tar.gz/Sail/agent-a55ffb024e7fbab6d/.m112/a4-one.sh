#!/bin/bash
# Diagnose: rerun exactness on one ironkv transcript with the current tool.
cd ~/sail
. .m112/env.sh
cargo build -q --release -p sail-bench --target-dir ~/tgt-diag
f=$(python3 -c "
import json
for l in open('/home/ubuntu/m112/exact-ironkv.jsonl'):
    r=json.loads(l)
    if r['trace'] and r['trace']['differ']: print(r['file']); break
")
echo "$f"
~/tgt-diag/release/sail-bench snapshot-exactness --z3 "$SAIL_PERF_FORK_DIR/z3" --lib "$SNAP_LIB" --dir /tmp/sxd --points 2 --json /tmp/diag.jsonl "$f" 2>/dev/null
python3 -c "
import json
r=json.loads(open('/tmp/diag.jsonl').readline())
for k in ('trace','marked'):
    print(k, repr((r[k] or {}).get('first_diff')))
"
