#!/bin/bash
# Host A (alone): solver-side edit cost through sail-z3, off vs snapshots.
set -uo pipefail
until grep -q A5-DONE ~/m112/a5.log; do sleep 60; done
cd ~/sail
. .m112/env.sh
cargo build -q --release -p sail-cli -p sail-shim
E=~/m112
Z3="$SAIL_PERF_FORK_DIR/z3"
edits="body-early body-late lemma-mid fail fix comment-top spec-wide"
for p in ironkv anvil; do
  dirs=""; for e in $edits; do dirs="$dirs $E/$p/trace/$e"; done
  echo "== $p (load $(cut -d' ' -f1 /proc/loadavg))"
  python3 scripts/snapshot-edit-replay.py --sail target/release --z3 "$Z3" --base $E/$p/trace/base --edit $dirs --out $E/rp-$p --label off
  for g in 1000 250; do
    python3 scripts/snapshot-edit-replay.py --sail target/release --z3 "$Z3" --lib "$SNAP_LIB" --gap-ms $g \
      --base $E/$p/trace/base --edit $dirs --out $E/rp-$p --label snap-g$g
  done
done
echo A7-DONE
