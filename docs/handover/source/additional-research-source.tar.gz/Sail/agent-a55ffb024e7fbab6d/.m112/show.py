import json, sys, collections
f = sys.argv[1]
keys = collections.Counter()
for line in open(f):
    r = json.loads(line)
    for kind in ("trace", "marked"):
        c = r.get(kind)
        if c and c.get("first_diff"):
            print(kind, r["file"].split("/")[-1], c["differ"], c["first_diff"][:700])
            print()
    for x in r.get("resumes", []):
        if x["cmp"].get("first_diff"):
            print("resume", r["file"].split("/")[-1], x["point"], x["cmp"]["differ"], x["cmp"]["first_diff"][:300])
            break
