#!/bin/bash
# Host A step 1: ironkv transcripts (fork Verus), then exactness on them.
set -uo pipefail
cd ~/sail
. .m112/env.sh
E=~/m112
mkdir -p $E
SAIL_PERF_FORK="$SAIL_PERF_FORK_DIR" SAIL_PERF_OUT=$E/ironkv scripts/perf-real.sh trace ironkv > $E/ironkv-trace.log 2>&1
tail -12 $E/ironkv-trace.log
./target/release/sail-bench snapshot-exactness --z3 "$SAIL_PERF_FORK_DIR/z3" --lib "$SNAP_LIB" --dir /tmp/sx --points 8 --jobs 8 \
  --json $E/exact-ironkv-base.jsonl $E/ironkv/trace/base > $E/exact-ironkv-base.txt 2> $E/exact-ironkv-base.err
cat $E/exact-ironkv-base.txt
grep -c "^DIFF" $E/exact-ironkv-base.err
