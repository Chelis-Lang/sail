#!/bin/bash
# Host B, after b2: anvil through the shim (fork Verus, cargo verus focus),
# without and with snapshots. One run at a time.
set -uo pipefail
until grep -q B2-DONE ~/m112/b2.log; do sleep 60; done
cd ~/sail
. .m112/env.sh
E=~/m112
export SAIL_PERF_SNAPSHOT_LIB="$SNAP_LIB" SAIL_PERF_FORK="$SAIL_PERF_FORK_DIR"
export SAIL_PERF_MODES="shim shim-snap"
export SAIL_PERF_MACHINE="EC2 c7i.4xlarge us-east-1 (lane m11-2 host m112b), nothing else running"
rm -rf $E/t-anvil-shim
SAIL_PERF_OUT=$E/t-anvil-shim bash scripts/perf-real-shim.sh run anvil 2 > $E/t-anvil-shim.log 2>&1
echo B3-DONE
