#!/bin/bash
cd ~/sail
cat ~/fetch-verus.txt | tail -5
ls ~/.cache/sail/verus/
