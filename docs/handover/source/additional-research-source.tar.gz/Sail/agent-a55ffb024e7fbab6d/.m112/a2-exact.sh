#!/bin/bash
# Exactness over trace dirs: a2-exact.sh NAME Z3 POINTS DIR...
set -uo pipefail
cd ~/sail
. .m112/env.sh
cargo build -q --release -p sail-bench
E=~/m112
name="$1" z3="$2" points="$3"; shift 3
./target/release/sail-bench snapshot-exactness --z3 "$z3" --lib "$SNAP_LIB" --dir /tmp/sx-$name --points "$points" --jobs "${JOBS:-8}" \
  --json $E/exact-$name.jsonl "$@" > $E/exact-$name.txt 2> $E/exact-$name.err
cat $E/exact-$name.txt
echo "DIFF lines: $(grep -c '^DIFF' $E/exact-$name.err)"
