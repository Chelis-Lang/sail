#!/bin/bash
pkill -f b1-timing.sh; pkill -f "perf-real.sh run"; sleep 1
cat ~/m112/t-ironkv/r1/sail.cold.log | head -20
