#!/bin/bash
set -uo pipefail
cd ~/sail
. .m112/env.sh
E=~/m112
export SAIL_PERF_SNAPSHOT_LIB="$SNAP_LIB" SAIL_VERUS_BUILD="${FORK_ROOT%/}"
rm -rf $E/s0
SAIL_PERF_MODES="snap" SAIL_PERF_NOOPS=1 SAIL_PERF_EDITS="body-late" SAIL_PERF_OUT=$E/s0 scripts/perf-real.sh run ironkv 1 2>&1 | grep "  r1"
cat $E/s0/snapshots.tsv
cat $E/s0/r1/prov/snap.body-late/*.json | grep -o '"snapshot_resumed_at":[0-9]*' | head
