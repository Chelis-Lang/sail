#!/bin/bash
# bg.sh SCRIPT LOG: run SCRIPT detached on the host, output to ~/LOG.
mkdir -p ~/m112
nohup setsid bash "$1" > ~/"$2" 2>&1 < /dev/null &
echo "started $1 as $!"
