# Sourced on the hosts: PATH for stock Verus, sail binaries; fork dir.
. ~/.cargo/env
export PATH="$HOME/sail/target/release:$HOME/.cache/sail/verus/0.2026.10.04.426d8b0/verus-x86-linux:$PATH"
FORK_ROOT="$(ls -d ~/.cache/sail/verus-src-build/*/ | head -1)"
export SAIL_PERF_FORK_DIR="${FORK_ROOT}verus/source/target-verus/release"
export SNAP_LIB="$HOME/sail/target/sail-snap/libsail_snap.so"
export STOCK_Z3="$(dirname "$(command -v verus)")/z3"
