#!/bin/bash
# done.sh FILE PATTERN: succeed when ~/FILE contains PATTERN.
grep -q "$2" ~/"$1" 2>/dev/null
