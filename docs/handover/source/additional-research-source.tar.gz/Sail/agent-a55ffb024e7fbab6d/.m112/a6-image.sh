#!/bin/bash
cd ~/sail
image="sail-ci:$(ci/image-tag.sh)"
docker image inspect "$image" >/dev/null 2>&1 || docker buildx build --platform linux/amd64 -f ci/Dockerfile -t "$image" --load . > ~/m112/image-build.log 2>&1
docker image inspect "$image" >/dev/null 2>&1 && echo "IMAGE-OK $image" || echo IMAGE-FAILED
