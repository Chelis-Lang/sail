#!/bin/bash
# Host setup for lane m11-2 (run on the EC2 host, in ~/sail).
set -euo pipefail
exec > >(tee -a ~/setup.log) 2>&1
sudo apt-get install -yq unzip >/dev/null
if ! command -v rustup >/dev/null; then
  curl -fsSL https://sh.rustup.rs | sh -s -- -y --default-toolchain none --profile minimal
fi
. ~/.cargo/env
cd ~/sail
rustup show active-toolchain || rustup toolchain install
rustup toolchain install 1.98.1 --profile minimal
cargo install cargo-nextest --locked -q 2>/dev/null || true
cargo build --release -p sail-cli -p sail-shim -p sail-bench -p sail-conformance
native/sail-snap/build.sh
python3 ci/engine-artifact.py fetch --pin engine/verus/artifact-linux.json --cache ~/.cache/sail
cargo xtask fetch-verus | tee ~/fetch-verus.txt
./target/release/sail-conformance fetch --tier standard --project anvil
./target/release/sail-conformance fetch --tier standard --project verified-ironkv
echo SETUP-DONE
