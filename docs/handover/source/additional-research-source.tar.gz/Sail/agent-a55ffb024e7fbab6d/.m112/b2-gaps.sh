#!/bin/bash
# Host B, after b1: ironkv snapshot gap sweep (snap mode only), one run at a time.
set -uo pipefail
until grep -q B1-DONE ~/m112/b1.log; do sleep 60; done
cd ~/sail
. .m112/env.sh
E=~/m112
export SAIL_PERF_SNAPSHOT_LIB="$SNAP_LIB" SAIL_VERUS_BUILD="${FORK_ROOT%/}"
export SAIL_PERF_MODES="snap"
export SAIL_PERF_MACHINE="EC2 c7i.4xlarge us-east-1 (lane m11-2 host m112b), nothing else running"
for g in 250 0; do
  rm -rf $E/t-ironkv-g$g
  SAIL_PERF_SNAPSHOT_GAP_MS=$g SAIL_PERF_OUT=$E/t-ironkv-g$g scripts/perf-real.sh run ironkv 2 > $E/t-ironkv-g$g.log 2>&1
done
echo B2-DONE
