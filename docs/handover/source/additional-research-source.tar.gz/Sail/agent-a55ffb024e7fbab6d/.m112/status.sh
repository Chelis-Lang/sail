#!/bin/bash
# status.sh: what is running, and the tail of each log.
uptime
pgrep -af 'perf-real|a3-traces|b1-timing|snapshot-exactness|sail-conformance|ci/run.sh' | grep -v pgrep | cut -c1-150 | head -8
for f in ~/m112/*.log; do echo "== $f"; tail -4 "$f"; done 2>/dev/null
echo "z3 processes: $(pgrep -c z3)"
free -g | head -2
