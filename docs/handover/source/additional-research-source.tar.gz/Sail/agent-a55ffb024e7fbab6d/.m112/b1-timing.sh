#!/bin/bash
# Host B: timed edit loops, plain vs sail vs sail+snapshots. One run at a time.
set -uo pipefail
cd ~/sail
. .m112/env.sh
cargo build -q --release -p sail-cli -p sail-shim -p sail-bench -p sail-conformance
native/sail-snap/build.sh
E=~/m112
mkdir -p $E
export SAIL_PERF_SNAPSHOT_LIB="$SNAP_LIB"
export SAIL_VERUS_BUILD="${FORK_ROOT%/}"
rm -rf $E/t-ironkv $E/t-anvil
export SAIL_PERF_MODES="plain sail snap"
export SAIL_PERF_MACHINE="EC2 c7i.4xlarge us-east-1 (lane m11-2 host m112b), nothing else running"
SAIL_PERF_OUT=$E/t-ironkv scripts/perf-real.sh run ironkv 3 > $E/t-ironkv.log 2>&1
SAIL_PERF_OUT=$E/t-anvil scripts/perf-real.sh run anvil 2 > $E/t-anvil.log 2>&1
echo B1-DONE
