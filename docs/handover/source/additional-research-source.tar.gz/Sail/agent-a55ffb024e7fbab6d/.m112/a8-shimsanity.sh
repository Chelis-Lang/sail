#!/bin/bash
set -uo pipefail
cd ~/sail
. .m112/env.sh
E=~/m112
export SAIL_PERF_SNAPSHOT_LIB="$SNAP_LIB" SAIL_PERF_FORK="$SAIL_PERF_FORK_DIR"
rm -rf $E/s1
SAIL_PERF_MODES="shim shim-snap" SAIL_PERF_NOOPS=1 SAIL_PERF_EDITS="body-late" SAIL_PERF_OUT=$E/s1 scripts/perf-real.sh run ironkv 1 2>&1 | grep "  r1"
cat $E/s1/snapshots.tsv
grep -h -o '"snapshot_resumed_at":[0-9]\+' -r $E/s1/r1/prov/ | head
