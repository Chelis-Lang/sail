"""Aggregate snapshot-exactness JSON lines: analyze.py FILE..."""
import json, sys, statistics, collections

for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    agg = collections.Counter()
    keys = collections.Counter()
    per_snap_pss = []
    fork_ms = []
    resume_secs_small = []
    for r in rows:
        agg["transcripts"] += 1
        agg["errors"] += r["error"] is not None
        agg["checks"] += r["checks"]
        agg["points"] += r["points"]
        agg["parked"] += r["parked"]
        for kind in ("trace", "marked"):
            c = r.get(kind)
            if c:
                agg[kind + "_runs"] += 1
                agg[kind + "_exact"] += c["same_count"] and c["differ"] == 0
                agg[kind + "_replies"] += c["compared"]
                agg[kind + "_nonstats"] += c["non_stats_differ"]
                agg[kind + "_differ"] += c["differ"]
                for k, n in c["stat_keys"].items():
                    keys[(kind, k)] += n
        for x in r["resumes"]:
            c = x["cmp"]
            agg["resume_runs"] += 1
            agg["resume_exact"] += c["same_count"] and c["differ"] == 0
            agg["resume_replies"] += c["compared"]
            agg["resume_identical"] += c["identical"]
            agg["resume_nonstats"] += c["non_stats_differ"]
            agg["resume_differ"] += c["differ"]
            agg["resume_badstatus"] += x["status"] != 0
            for k, n in c["stat_keys"].items():
                keys[("resumed", k)] += n
            if c["compared"] <= 12:
                resume_secs_small.append(x["secs"])
        if r.get("parked_kb") and r["parked"]:
            per_snap_pss.append(r["parked_kb"][1] / r["parked"] / 1024)
        if r["points"] and r["marked_secs"] and r["fresh_secs"]:
            fork_ms.append((r["marked_secs"] - r["fresh_secs"]) / r["points"] * 1000)
    print(f"== {f}")
    print(dict(agg))
    print("stat keys:", dict(keys))
    if per_snap_pss:
        print(f"pss per snapshot MB: median {statistics.median(per_snap_pss):.1f}, max {max(per_snap_pss):.1f}")
    if fork_ms:
        print(f"marked-fresh per point ms: median {statistics.median(fork_ms):.1f}")
    if resume_secs_small:
        print(f"resume with <=12 replies left, s: median {statistics.median(resume_secs_small):.3f}, min {min(resume_secs_small):.3f}, n {len(resume_secs_small)}")
