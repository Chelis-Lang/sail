#!/usr/bin/env bash
# exprun.sh --bg PROJECT CMD...  runs exp.py CMD PROJECT for each CMD in turn (log ~/exp-PROJECT.log)
set -euo pipefail
if [ "${1:-}" = --bg ]; then
  shift
  setsid nohup "$0" "$@" >"$HOME/exp-$1.log" 2>&1 </dev/null &
  echo "started: ~/exp-$1.log"; exit 0
fi
. ~/.cargo/env
export PATH="$HOME/bin:$PATH"
p="$1"; shift
if ! command -v summarize >/dev/null; then
  cargo +1.99.0 install --locked -q --git https://github.com/rust-lang/measureme --tag 12.0.3 summarize 2>&1 | tail -2 || true
fi
for c in "$@"; do
  echo "=== $c $(date +%T) load $(cut -d' ' -f1 /proc/loadavg)"
  python3 ~/sail/m118-tmp/exp.py "$c" "$p" || echo "exp $c failed"
done
echo exprun-done
