#!/usr/bin/env bash
# M11-8 floor profile on one host: perf-real runs with the timers fork.
# Usage: measure.sh --bg PROJECT...   (runs each project in turn; log ~/measure.log)
set -euo pipefail
if [ "${1:-}" = --bg ]; then
  shift
  setsid nohup "$0" "$@" >"$HOME/measure.log" 2>&1 </dev/null &
  echo "started: ~/measure.log"; exit 0
fi
. ~/.cargo/env
export PATH="$HOME/bin:$PATH"
cd ~/sail
build=$(ls -d ~/.cache/sail/verus-src-build/* | while read -r d; do
  r=$(find "$d" -path '*target-verus/release/cargo-verus' 2>/dev/null | head -1)
  [ -n "$r" ] && grep -q 520f3b57 "$d"/*.json 2>/dev/null && echo "$d"; done | head -1)
[ -n "$build" ] || { echo "no timers build"; exit 1; }
rt=$(dirname "$(find "$build" -path '*target-verus/release/cargo-verus' | head -1)")
echo "build $build"; echo "runtime $rt"
stock=$(dirname "$(find ~/.cache/sail/verus -name cargo-verus -type f | head -1)")
export PATH="$stock:$PATH"
export SAIL_PERF_FORK="$rt" SAIL_PERF_VERUS_BUILD="$build"
export SAIL_PERF_MACHINE="EC2 c7i.4xlarge us-east-1 (m11-8)"
for p in "$@"; do
  case "$p" in
    anvil)
      SAIL_PERF_OUT=~/out/$p-sail SAIL_PERF_MODES="fork-sail" SAIL_PERF_NOOPS=3 \
        SAIL_PERF_EDITS="body-early lemma-mid" scripts/perf-real.sh run anvil 2
      SAIL_PERF_OUT=~/out/$p-plain SAIL_PERF_MODES="fork-plain" SAIL_PERF_NOOPS=1 \
        SAIL_PERF_EDITS="body-early" scripts/perf-real.sh run anvil 1 ;;
    *)
      SAIL_PERF_OUT=~/out/$p SAIL_PERF_MODES="fork-plain fork-sail" SAIL_PERF_NOOPS=3 \
        SAIL_PERF_EDITS="body-early lemma-mid spec-wide" scripts/perf-real.sh run "$p" 2 ;;
  esac
done
echo measure-done
