#!/usr/bin/env bash
# M11-8 host setup: toolchains, stock Verus, pinned fork runtime, then (with a
# fork commit) the timers fork build and a Sail release build pinned to it
# (host copy of fork.toml only). Usage: host-setup.sh TIMERS_FORK_COMMIT
set -euo pipefail
if [ "${1:-}" = --bg ]; then
  shift
  setsid nohup "$0" "$@" >"$HOME/setup.log" 2>&1 </dev/null &
  echo "started in background: ~/setup.log"
  exit 0
fi
cd ~/sail
sudo DEBIAN_FRONTEND=noninteractive apt-get install -yq cmake ninja-build time unzip >/dev/null 2>&1 || true
if ! command -v rustup >/dev/null 2>&1 && [ ! -x ~/.cargo/bin/rustup ]; then
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain none >/dev/null
fi
. ~/.cargo/env
sail_tc="$(sed -n 's/^channel = "\(.*\)"/\1/p' rust-toolchain.toml)"
verus_tc="$(sed -n '/^rust_toolchain = /{s/^rust_toolchain = "\(.*\)"/\1/p;q;}' corpus/toolchain.toml)"
rustup toolchain install "$sail_tc" --profile minimal >/dev/null 2>&1
rustup toolchain install "$verus_tc" --profile minimal -t x86_64-unknown-none >/dev/null 2>&1
echo "toolchains: $sail_tc $verus_tc"
cargo xtask fetch-verus >/dev/null
python3 ci/engine-artifact.py fetch --pin engine/verus/artifact-linux.json --cache ~/.cache/sail >/dev/null
echo "pinned runtime: $(ls ~/.cache/sail/verus-src-build/)"
cp engine/verus/fork.toml ~/fork.toml.orig
sed -i "s/^commit = .*/commit = \"$1\"/" engine/verus/fork.toml
cargo build --release -q -p sail-cli -p sail-shim -p sail-conformance
mkdir -p ~/bin
for b in sail sail-z3 sail-conformance; do ln -sf ~/sail/target/release/$b ~/bin/$b; done
cargo xtask build-verus-engine --force 2>&1 | tail -5
ls ~/.cache/sail/verus-src-build/
echo setup-done
