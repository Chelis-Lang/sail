#!/usr/bin/env python3
"""M11-8 experiments on one project, after measure.sh (uses its pristine copy).

  exp.py keys PROJECT      per-bucket key and SMT digests across edits
                           (fork-plain, --output-json --time-expanded,
                           SAIL_M8_KEY_PROXY=1), written to ~/exp/PROJECT/*.json
  exp.py profile PROJECT   rustc -Z self-profile of an unchanged rerun
  exp.py macroopt PROJECT  noop reruns with the proc macros built at opt-level 0
                           (Cargo's dev default) and 3 (build-override), plus
                           SMT logs of both arms for a byte comparison
  exp.py hits PROJECT      the Verus arm under Sail's cache, all hits:
                           cargo verus with sail-z3 and the daemon, text timing
"""
import json, os, pathlib, re, shutil, subprocess, sys, time

HOME = pathlib.Path.home()
PROJ = {
    # name: (package dir, cargo args, verus args, noop file, edits)
    "vest": ("vest_lib", [], [], "vest_lib/src/asn1/der_ord.rs", [
        ("body-early", "body", "vest_lib/src/asn1/der_ord.rs", 245),
        ("comment-top", "comment", "vest_lib/src/asn1/der_ord.rs", 1),
        ("lemma-mid", "lemma", "vest_lib/src/asn1/der_ord.rs", 1770),
    ]),
    "ironkv": ("ironsht", [], [], "ironsht/src/host_impl_v.rs", [
        ("body-early", "body", "ironsht/src/host_impl_v.rs", 151),
        ("comment-top", "comment", "ironsht/src/host_impl_v.rs", 1),
        ("lemma-mid", "lemma", "ironsht/src/host_impl_v.rs", 1336),
    ]),
    "verismo": ("source/verismo", [], [], "source/verismo/src/security/mem.rs", [
        ("body-early", "body", "source/verismo/src/security/mem.rs", 191),
        ("comment-top", "comment", "source/verismo/src/security/mem.rs", 1),
        ("lemma-mid", "lemma", "source/verismo/src/security/mem.rs", 627),
    ]),
    "anvil": (".", ["--lib"], ["--verify-module", "vdeployment_controller"],
              "src/controllers/vdeployment_controller/proof/liveness/resource_match.rs", [
        ("comment-top", "comment", "src/controllers/vdeployment_controller/proof/liveness/resource_match.rs", 1),
        ("lemma-mid", "lemma", "src/controllers/vdeployment_controller/proof/liveness/resource_match.rs", 1106),
    ]),
}


def runtime():
    for d in sorted((HOME / ".cache/sail/verus-src-build").iterdir()):
        if "520f3b57" in (d / "sail-build.json").read_text(errors="replace"):
            for p in d.rglob("target-verus/release/cargo-verus"):
                return d, p.parent
    sys.exit("no timers build")


def stock():
    for p in (HOME / ".cache/sail/verus").rglob("cargo-verus"):
        if p.is_file():
            return p.parent
    sys.exit("no stock verus")


def body_open(s, frm, line):
    fn = s.index("fn ", frm)
    par = brk = 0
    i = fn
    while i < len(s):
        c = s[i]
        if s.startswith("//", i):
            i = s.index("\n", i)
            continue
        if c == "(":
            par += 1
        elif c == ")":
            par -= 1
        elif c == "[":
            brk += 1
        elif c == "]":
            brk -= 1
        elif c == "{" and par == 0 and brk == 0:
            return i
        i += 1
    raise SystemExit(f"no body at line {line}")


def apply(work, pristine, op, f, line, tag=""):
    src = (pristine / f).read_text()
    lines = src.splitlines(keepends=True)
    pos = sum(len(x) for x in lines[: line - 1])
    if op == "noop":
        src += f"// sail-perf noop {tag}\n"
    elif op == "body":
        o = body_open(src, pos, line)
        src = src[: o + 1] + " assert(true);" + src[o + 1 :]
    elif op == "comment":
        src = src[:pos] + "// sail-perf: an inserted comment line\n" + src[pos:]
    elif op == "lemma":
        i = line - 1
        while i > 0 and re.match(r"^\s*(#\[|//)", lines[i - 1]):
            i -= 1
        p = sum(len(x) for x in lines[:i])
        src = src[:p] + "pub proof fn sail_perf_new_lemma(x: int)\n    ensures\n        x + 0 == x,\n{\n}\n\n" + src[p:]
    (work / f).write_text(src)


def reset(work, pristine, files):
    for f in files:
        shutil.copy(pristine / f, work / f)


def first_json(text):
    dec = json.JSONDecoder()
    found = []
    for m in re.finditer(r"^\{", text, re.M):
        try:
            obj, _ = dec.raw_decode(text, m.start())
        except ValueError:
            continue
        if isinstance(obj, dict) and "times-ms" in obj:
            found.append(obj)
    return found


def main():
    cmd, name = sys.argv[1], sys.argv[2]
    pkg, cargs, vargs, noop_file, edits = PROJ[name]
    _, rt = runtime()
    env = dict(os.environ)
    env["PATH"] = f"{rt}:{stock()}:{HOME}/.cargo/bin:{env['PATH']}"
    for k in list(env):
        if k.startswith("SAIL_"):
            del env[k]
    pristine = HOME / "out" / name / "pristine"
    if not pristine.exists():
        pristine = HOME / "out" / f"{name}-sail" / "pristine"
    out = HOME / "exp" / name
    work = out / "proj"
    if not work.exists():
        out.mkdir(parents=True, exist_ok=True)
        shutil.copytree(pristine, work, symlinks=True)
    files = {noop_file} | {e[2] for e in edits}
    sub = "focus" if vargs else "verify"
    base = ["cargo", "verus", sub, *cargs, "--", *vargs]

    def run(tag, extra, env2=None, keep=True):
        t0 = time.time()
        p = subprocess.run(base + extra, cwd=work / pkg, env=env2 or env, capture_output=True, text=True)
        wall = time.time() - t0
        (out / f"{tag}.out").write_text(p.stdout)
        (out / f"{tag}.err").write_text(p.stderr)
        print(f"{tag}: exit {p.returncode} wall {wall:.2f}", flush=True)
        return p, wall

    if cmd == "keys":
        env["SAIL_M8_KEY_PROXY"] = "1"
        run("cold", [])
        states = [("noop1", "noop", noop_file, 0), ("noop2", "noop", noop_file, 0)] + edits
        for tag, op, f, line in states:
            reset(work, pristine, files)
            apply(work, pristine, "noop", noop_file, 0, tag)
            if op != "noop":
                apply(work, pristine, op, f, line)
            p, wall = run(tag, ["--output-json", "--time-expanded"])
            js = first_json(p.stdout)
            (out / f"{tag}.json").write_text(json.dumps({"wall": wall, "verus": js}))
    elif cmd == "macroopt":
        arms = [("o0", {}), ("o3", {"CARGO_PROFILE_DEV_BUILD_OVERRIDE_OPT_LEVEL": "3"}),
                ("o0b", {}), ("o3b", {"CARGO_PROFILE_DEV_BUILD_OVERRIDE_OPT_LEVEL": "3"})]
        for arm, extra in arms:
            aenv = dict(env)
            aenv.update(extra)
            tgt = out / f"target-{arm[:2]}"
            aenv["CARGO_TARGET_DIR"] = str(tgt)
            reset(work, pristine, files)
            if arm in ("o0", "o3"):
                run(f"mo-{arm}-cold", [], aenv)
            for i in range(3):
                apply(work, pristine, "noop", noop_file, 0, f"{arm}{i}")
                run(f"mo-{arm}-noop{i}", ["--time-expanded"], aenv)
            if arm in ("o0", "o3"):
                logd = out / f"smt-{arm}"
                shutil.rmtree(logd, ignore_errors=True)
                apply(work, pristine, "noop", noop_file, 0, "smt")
                run(f"mo-{arm}-smt", ["--log", "smt", "--log-dir", str(logd)], aenv)
    elif cmd == "hits":
        cache = out / "cache"
        shutil.rmtree(cache, ignore_errors=True)
        cache.mkdir(parents=True)
        sock = cache / "d.sock"
        denv = dict(env)
        denv["SAIL_CACHE_DIR"] = str(cache)
        daemon = subprocess.Popen([str(HOME / "bin/sail"), "serve", "--socket", str(sock)], env=denv,
                                  stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(200):
            if sock.exists():
                break
            time.sleep(0.05)
        henv = dict(env)
        henv["VERUS_Z3_PATH"] = str(HOME / "bin/sail-z3")
        henv["SAIL_Z3_PATH"] = str(rt / "z3")
        henv["SAIL_DAEMON_SOCKET"] = str(sock)
        henv["CARGO_TARGET_DIR"] = str(out / "target-hits")
        reset(work, pristine, files)
        run("hits-cold", ["--time-expanded"], henv)
        for i in range(4):
            apply(work, pristine, "noop", noop_file, 0, f"h{i}")
            run(f"hits{i}", ["--time-expanded"], henv)
        daemon.terminate()
    elif cmd == "profile":
        prof = out / "selfprofile"
        env2 = dict(env)
        env2["RUSTFLAGS"] = f"-Zself-profile={prof}"
        env2["RUSTC_BOOTSTRAP"] = "1"
        env2["CARGO_TARGET_DIR"] = str(out / "target-prof")
        reset(work, pristine, files)
        prof.mkdir(parents=True, exist_ok=True)
        run("prof-cold", ["--time-expanded"], env2)
        for i in range(2):
            apply(work, pristine, "noop", noop_file, 0, f"p{i}")
            shutil.rmtree(prof, ignore_errors=True)
            prof.mkdir(parents=True)
            run(f"prof{i}", ["--time-expanded"], env2)
            keep = out / f"selfprofile{i}"
            shutil.rmtree(keep, ignore_errors=True)
            shutil.copytree(prof, keep)


main()
