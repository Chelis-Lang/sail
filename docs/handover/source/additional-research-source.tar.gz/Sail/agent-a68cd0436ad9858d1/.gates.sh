#!/usr/bin/env bash
# Temporary (not committed): runs the required Linux gates for lane m11-7.
cd "$HOME/sail"
: > "$HOME/gates.summary"
for step in "gate" "solver" "e2e" "conformance fast pr"; do
  name="${step// /-}"
  # shellcheck disable=SC2086
  ci/local.sh $step > "$HOME/gate-$name.log" 2>&1
  echo "$step exit=$?" >> "$HOME/gates.summary"
done
echo done >> "$HOME/gates.summary"
