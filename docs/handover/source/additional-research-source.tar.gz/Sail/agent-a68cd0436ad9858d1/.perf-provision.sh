#!/usr/bin/env bash
# Temporary (not committed): provisions a native perf host for lane m11-7.
set -euo pipefail
sudo apt-get install -yq unzip >/dev/null
if ! command -v cargo >/dev/null && [ ! -x "$HOME/.cargo/bin/cargo" ]; then
  curl -fsSL https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain none >/dev/null
fi
. "$HOME/.cargo/env"
cd "$HOME/sail"
cargo build --release -p sail-cli -p sail-shim 2>&1 | tail -1
python3 ci/engine-artifact.py fetch --pin engine/verus/artifact-linux.json --cache "$HOME/.cache/sail" 2>&1 | tail -2
cargo xtask fetch-verus 2>&1 | tail -2
cd "$HOME/sail-main"
cargo build --release -p sail-cli -p sail-shim 2>&1 | tail -1
mkdir -p "$HOME/base" && cp target/release/sail target/release/sail-z3 "$HOME/base/"
git clone -q https://github.com/secure-foundations/vest "$HOME/vest-src"
echo provisioned
