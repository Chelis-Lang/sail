#!/usr/bin/env bash
# Temporary (not committed): runs perf-loops for lane m11-7 on the native host.
set -euo pipefail
project="$1"
rounds="${2:-3}"
. "$HOME/.cargo/env"
cd "$HOME/sail"
export PATH="$PWD/target/release:$HOME/.cache/sail/verus/0.2026.10.04.426d8b0/verus-x86-linux:$PATH"
export SAIL_VERUS_BUILD="$(ls -d "$HOME"/.cache/sail/verus-src-build/*/ | head -1)"
export SAIL_PERF_MACHINE="EC2 c7i.4xlarge (16 vCPU, 30 GiB), us-east-1, Ubuntu 24.04, scripts/perf-host.sh up m11-7p, no other work on the host"
export SAIL_PERF_BASELINES="main=$HOME/base"
export SAIL_PERF_VEST_SRC="$HOME/vest-src"
export SAIL_PERF_OUT="$HOME/sp/$project"
rm -rf "$SAIL_PERF_OUT"
scripts/perf-loops.sh "$project" "$rounds" > "$HOME/perf-$project.log" 2>&1
echo "exit=$?" >> "$HOME/perf-$project.log"
